author: Wout Dillen

title: A Simple Markup Example in Markdown

date: February 2022

---

# Frankenstein (1931)
## Script Excerpt

**Victor Frankenstein:** "It's _ALIVE_ !"